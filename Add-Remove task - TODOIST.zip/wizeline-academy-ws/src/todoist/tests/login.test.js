//fixtures define mis tests
//test controler es como driver. en selenium
//en fixtures no necesito importar el test controler, en pages si es necesario
//(t) => es lo mismo que "function(t)"   (se pueden omitir parentesis como en segundo test)
//usar await cuando una clase sera sincrona
//necesito crear variables desde consola para setear valores a EMAIL y PASSWORD con "set TODOIST_PASSWORD=wizeline" o export en mac
// testcafe chrome src/todoist/test/login.test.js para ejecutar mi test mandando ubicacion


import LoginPage from '../pages/login.page.js';
import DashboardPage from '../pages/dashboard.page';
import data from '../utils/data';

//const USER = process.env.TODOIST_EMAIL;
//const PASSWORD = process.env.TODOIST_PASSWORD;
const EMAIL = "sam.rm91@gmail.com";
const PASSWORD = "wizeline";

console.log(EMAIL);
console.log(PASSWORD);

fixture("Login Tests").page(data.url.toString());
//para aplicar hooks en testcafe
//fixture('msg').page('url').beforeEach(async t => {})

//test('name', function(t){
//});
test("Login Unsuccessfull", async t => {
    await LoginPage.login(EMAIL, data.wrongPass.toString(), null);
    await t.expect(await LoginPage.isErrorVisible()).ok();
    //t.expect((await LoginPage.isErrorVisible()).includes("incorrect"));
    await t.expect(await LoginPage.isErrorVisible()).contains(data.incorrectMsg.toString());
});

test("Login successfull", async t => {
    await LoginPage.login(EMAIL, PASSWORD, data.goIntoFrame.toString());
    await t.expect(await DashboardPage.isPageLoaded()).ok();
});