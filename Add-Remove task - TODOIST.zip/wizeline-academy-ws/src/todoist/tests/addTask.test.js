import LoginPage from "../pages/login.page";
import DashboardPage from '../pages/dashboard.page';
import data from '../utils/data';

//const USER = process.env.TODOIST_EMAIL;
//const PASSWORD = process.env.TODOIST_PASSWORD;
const USER = "sam.rm91@gmail.com";
const PASSWORD = "wizeline";

fixture("Adding task").page(data.url.toString());

test("Add task successfully", async t => {
    await LoginPage.login(USER, PASSWORD, data.goIntoFrame.toString());
    await t.expect(await DashboardPage.isPageLoaded()).ok();
    await DashboardPage.addNewTask(data.taskName.toString());
    await t.expect(await DashboardPage.isItemAdded()).ok();
    await t.wait(5000);
});

test("Delete added task", async t => {
    await LoginPage.login(USER, PASSWORD, data.goIntoFrame.toString());
    await DashboardPage.deleteTask();
    await t.expect(await DashboardPage.isTaskDeleted()).ok();
});