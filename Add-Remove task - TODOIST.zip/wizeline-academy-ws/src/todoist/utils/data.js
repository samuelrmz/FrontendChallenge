
export default {
    // Test Data Provider
    url:'https://todoist.com/',
    goIntoFrame:'yes',
    incorrectMsg: 'incorrect',
    wrongPass:'1234',
    taskName:'Task_01',
};