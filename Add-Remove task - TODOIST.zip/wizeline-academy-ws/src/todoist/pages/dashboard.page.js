import { Selector, t } from 'testcafe';
import data from '../utils/data';

class DashboardPage {
    //constructor para login.test.js
    constructor() {
        this.todoistIcon = Selector("svg[data-svgs-path='sm1/todoist_logo.svg']");
        this.addTaskIcon = Selector(".agenda_add_task .action");
        this.addName = Selector("[data-offset-key] div");
        this.addTaskButton = Selector(".item_editor_actions>button");
        this.cancelButton = Selector(".item_editor_actions>.cancel");
        this.newAddedTask = Selector(".task_item_content_text").withExactText(data.taskName.toString());
        this.hoverBar = Selector(".task_item_details + div .column_project");
        this.menuIcon = Selector(".task_item_actions .icon");
        this.deleteText = Selector(".sel_delete_task .menu_label").nth(2);
        this.confirmDeletionButton = Selector(".reactist_modal_box__actions .ist_button_red");
        this.assertDeletion = Selector(".empty-state");
    }

    async isPageLoaded() {
        return this.todoistIcon.visible;
        //this.todoistIcon.exists;
        //await... && await t.expect(this.todoistIcon.exists).ok()
    }

    async addNewTask(taskName) {
        await t.click(this.addTaskIcon);
        for (var i = 0; i < String(taskName).length; i++) {
            await t.pressKey(String(taskName).charAt(i));
        }
        await t.click(this.addTaskButton);
        await t.click(this.cancelButton);
    }

    async isItemAdded() {
        return this.newAddedTask.visible;
    }

    async deleteTask() {
        await t.hover(this.hoverBar);
        await t.click(this.menuIcon);
        await t.click(this.deleteText);
        await t.click(this.confirmDeletionButton);
    }

    async isTaskDeleted() {
        return this.assertDeletion.visible;
    }
}

export default new DashboardPage();