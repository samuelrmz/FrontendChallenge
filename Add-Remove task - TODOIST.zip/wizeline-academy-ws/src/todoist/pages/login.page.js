//class es como function() pero en ecma6
//dentro de constructor creo mis objectos
//en mi page si requiero importar selector para usar locators
//nth me saca un elemento como si fuera arreglo de locators iniciando primer elemento en 0
//async se usa para indicar que mi test es sincrono
//para importar varias clases al mismo tiempo uso ',' dentro llaves

import { Selector, t } from 'testcafe';

class LoginPage {
    //constructor para login.test.js
    constructor() {
        //this.loginLink = Selector('ul.W9ktc > li:nth-child(1) > a').withExactText('Iniciar Sesión').nth(0);
        this.loginLink = Selector('ul.W9ktc > li:nth-child(1) > a');
        this.loginFrame = Selector("iframe[src*='showLogin']");

        this.emailField = Selector("#email");
        this.passwordField = Selector("#password");
        this.loginButton = Selector(".submit_btn");
        this.errorMessage = Selector(".error_msg>span");
    }

    async login(email, password, getIntoFrame) {
        //se pueden contacatenar waits como se muestra abajo o separandolos
        await t.wait(3000);
        await this.loginLink.with({ visibilityCheck: true })();
        await t.click(this.loginLink);
        await t.switchToIframe(this.loginFrame);
        await t.typeText(this.emailField, email);
        await t.typeText(this.passwordField, password);
        await t.click(this.loginButton);
        if (getIntoFrame) {
            await t.switchToMainWindow();
        }
    }

    async isErrorVisible() {
        //return this.errorMessage.exists;
        //return this.errorMessage.visible;
        return this.errorMessage.textContent;
    }
}

//exporta la clase y crea nuevo objecto con ese nombre
export default new LoginPage();